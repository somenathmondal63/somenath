/**
 * db.js — Simple JSON file-based database
 * In production, replace with MongoDB/PostgreSQL/MySQL as needed.
 * All read/write operations are synchronous for simplicity.
 */

const fs = require('fs');
const path = require('path');

const DATA_DIR = path.join(__dirname, 'data');
const DB_FILE  = path.join(DATA_DIR, 'database.json');

// ─── Default seed data ────────────────────────────────────────────────────────
const DEFAULT_DATA = {
  business: {
    name:        'Somenath Pharmacy',
    tagline:     'X-Ray & Blood Test Centre',
    owner:       'Somenath Mondal',
    address:     '',
    phone:       '',
    whatsapp:    '',
    email:       '',
    monsat:      '7:00 AM – 9:00 PM',
    sunday:      '8:00 AM – 2:00 PM',
    emergency:   'On Call',
    maps_embed:  '',
    maps_address:''
  },

  medicines: [
    { id:'m1',  name:'Paracetamol 500mg',   category:'Pain Relief',    status:'available' },
    { id:'m2',  name:'Amoxicillin 500mg',   category:'Antibiotic',     status:'available' },
    { id:'m3',  name:'Metformin 500mg',      category:'Diabetes',       status:'available' },
    { id:'m4',  name:'Atorvastatin 10mg',   category:'Blood Pressure', status:'limited'   },
    { id:'m5',  name:'Cetirizine 10mg',     category:'Allergy',        status:'available' },
    { id:'m6',  name:'Omeprazole 20mg',     category:'Antacid',        status:'available' },
    { id:'m7',  name:'Vitamin D3 60K',      category:'Vitamins',       status:'available' },
    { id:'m8',  name:'Amlodipine 5mg',      category:'Blood Pressure', status:'out'       },
    { id:'m9',  name:'Azithromycin 500mg',  category:'Antibiotic',     status:'limited'   },
    { id:'m10', name:'Pantoprazole 40mg',   category:'Antacid',        status:'available' },
    { id:'m11', name:'Vitamin B12',         category:'Vitamins',       status:'available' },
    { id:'m12', name:'Glibenclamide 5mg',   category:'Diabetes',       status:'available' },
    { id:'m13', name:'Ibuprofen 400mg',     category:'Pain Relief',    status:'available' },
    { id:'m14', name:'Losartan 50mg',       category:'Blood Pressure', status:'limited'   }
  ],

  doctors: [
    {
      id: 'd1',
      name:     'Dr. [Name Here]',
      spec:     'General Physician · MBBS, MD',
      schedule: 'Monday, Wednesday, Friday · 5:00 PM – 8:00 PM',
      exp:      '10+ years experience. Expert in general medicine, fever, infections, and chronic illness management.',
      lang:     'Bengali, Hindi, English',
      emoji:    '👨‍⚕️'
    },
    {
      id: 'd2',
      name:     'Dr. [Name Here]',
      spec:     'Radiologist · MBBS, DMRD',
      schedule: 'Tuesday, Thursday · 4:00 PM – 7:00 PM',
      exp:      'Specialist in X-Ray and diagnostic imaging. Provides quick and accurate radiological reports.',
      lang:     'Bengali, Hindi',
      emoji:    '👩‍⚕️'
    },
    {
      id: 'd3',
      name:     'Dr. [Name Here]',
      spec:     'Pathologist · MBBS, MD (Path)',
      schedule: 'Saturday · 10:00 AM – 1:00 PM',
      exp:      'Expert in blood test analysis, CBC, diabetes profiling, lipid panels, and preventive diagnostics.',
      lang:     'Bengali, English',
      emoji:    '👨‍⚕️'
    }
  ],

  reviews: [
    {
      id: 'r1', name: 'Rahul Das', rating: 5,
      text: 'Excellent service! All the medicines were available and the staff was very helpful. The blood test reports came within hours. Highly recommended!',
      date: 'March 2025', approved: true, media: []
    },
    {
      id: 'r2', name: 'Priya Sarkar', rating: 5,
      text: 'Got my X-Ray done here — very quick and the report was accurate. The visiting doctor explained everything clearly. Great experience overall.',
      date: 'February 2025', approved: true, media: []
    },
    {
      id: 'r3', name: 'Amit Ghosh', rating: 4,
      text: 'Very affordable pricing for blood tests. Somenath ji is very kind and knowledgeable. The pharmacy has a good stock of medicines always.',
      date: 'January 2025', approved: true, media: []
    }
  ],

  // Other admins (main admin stored only in .env, never here)
  admins: [],

  gallery: []
};

// ─── Helpers ─────────────────────────────────────────────────────────────────

function ensureDataDir() {
  if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
}

function read() {
  ensureDataDir();
  if (!fs.existsSync(DB_FILE)) {
    write(DEFAULT_DATA);
    return JSON.parse(JSON.stringify(DEFAULT_DATA));
  }
  try {
    return JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));
  } catch {
    write(DEFAULT_DATA);
    return JSON.parse(JSON.stringify(DEFAULT_DATA));
  }
}

function write(data) {
  ensureDataDir();
  fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2), 'utf8');
}

function get(key) {
  return read()[key];
}

function set(key, value) {
  const data = read();
  data[key] = value;
  write(data);
  return value;
}

function reset() {
  write(DEFAULT_DATA);
}

module.exports = { read, write, get, set, reset };
