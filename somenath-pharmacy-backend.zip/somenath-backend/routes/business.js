/**
 * routes/business.js
 * Public read + Admin update for business info (address, hours, phone, maps).
 */

const express = require('express');
const router  = express.Router();
const db      = require('../db');
const { requireAuth } = require('../middleware/auth');

// ─── GET /api/business ───────────────────────────────────────────────────────
// Public: anyone can read business info
router.get('/', (req, res) => {
  try {
    const business = db.get('business');
    res.json({ success: true, data: business });
  } catch (err) {
    console.error('[Business/GET]', err);
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

// ─── PUT /api/business ───────────────────────────────────────────────────────
// Admin only: update business info
router.put('/', requireAuth, (req, res) => {
  try {
    const allowed = ['address', 'phone', 'whatsapp', 'email', 'monsat', 'sunday', 'emergency', 'maps_embed', 'maps_address'];
    const current = db.get('business');
    const updated = { ...current };

    for (const key of allowed) {
      if (req.body[key] !== undefined) {
        updated[key] = String(req.body[key]).trim();
      }
    }

    db.set('business', updated);
    res.json({ success: true, message: 'Business info updated.', data: updated });
  } catch (err) {
    console.error('[Business/PUT]', err);
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

module.exports = router;
