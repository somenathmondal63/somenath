/**
 * routes/gallery.js
 * Shop gallery photo management.
 * Public: GET
 * Admin: POST (upload), DELETE
 */

const express = require('express');
const router  = express.Router();
const multer  = require('multer');
const path    = require('path');
const fs      = require('fs');
const { v4: uuidv4 } = require('uuid');
const db      = require('../db');
const { requireAuth } = require('../middleware/auth');

// ─── Multer storage ───────────────────────────────────────────────────────────
const UPLOAD_DIR = path.join(__dirname, '..', 'uploads', 'gallery');
if (!fs.existsSync(UPLOAD_DIR)) fs.mkdirSync(UPLOAD_DIR, { recursive: true });

const storage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, UPLOAD_DIR),
  filename:    (_req, file, cb) => {
    const ext  = path.extname(file.originalname).toLowerCase();
    cb(null, `${uuidv4()}${ext}`);
  }
});

const fileFilter = (_req, file, cb) => {
  const allowed = /jpeg|jpg|png|gif|webp/;
  if (allowed.test(path.extname(file.originalname).toLowerCase())) return cb(null, true);
  cb(new Error('Only image files are allowed in the gallery.'));
};

const upload = multer({
  storage,
  fileFilter,
  limits: { fileSize: (parseInt(process.env.MAX_UPLOAD_MB) || 10) * 1024 * 1024 }
});

// ─── GET /api/gallery ─────────────────────────────────────────────────────────
router.get('/', (req, res) => {
  try {
    const gallery = db.get('gallery') || [];
    res.json({ success: true, total: gallery.length, data: gallery });
  } catch (err) {
    console.error('[Gallery/GET]', err);
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

// ─── POST /api/gallery ────────────────────────────────────────────────────────
// Admin: upload photo(s) to gallery (up to 10 at once)
router.post('/', requireAuth, upload.array('photos', 10), (req, res) => {
  try {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({ success: false, message: 'No image files provided.' });
    }

    const gallery  = db.get('gallery') || [];
    const uploaded = req.files.map(f => {
      const item = {
        id:       uuidv4(),
        filename: f.filename,
        label:    (req.body.label || '').trim() || f.originalname,
        url:      `/uploads/gallery/${f.filename}`,
        uploadedAt: new Date().toISOString()
      };
      gallery.push(item);
      return item;
    });

    db.set('gallery', gallery);
    res.status(201).json({
      success: true,
      message: `${uploaded.length} photo(s) uploaded.`,
      data: uploaded
    });
  } catch (err) {
    console.error('[Gallery/POST]', err);
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

// ─── PUT /api/gallery/:id ─────────────────────────────────────────────────────
// Admin: update photo label
router.put('/:id', requireAuth, (req, res) => {
  try {
    const gallery = db.get('gallery') || [];
    const idx = gallery.findIndex(g => g.id === req.params.id);
    if (idx === -1) return res.status(404).json({ success: false, message: 'Photo not found.' });

    if (req.body.label) gallery[idx].label = req.body.label.trim();
    db.set('gallery', gallery);
    res.json({ success: true, message: 'Photo updated.', data: gallery[idx] });
  } catch (err) {
    console.error('[Gallery/PUT]', err);
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

// ─── DELETE /api/gallery/:id ──────────────────────────────────────────────────
// Admin: delete a gallery photo
router.delete('/:id', requireAuth, (req, res) => {
  try {
    const gallery = db.get('gallery') || [];
    const idx = gallery.findIndex(g => g.id === req.params.id);
    if (idx === -1) return res.status(404).json({ success: false, message: 'Photo not found.' });

    // Delete physical file
    const filePath = path.join(UPLOAD_DIR, gallery[idx].filename);
    if (fs.existsSync(filePath)) fs.unlinkSync(filePath);

    gallery.splice(idx, 1);
    db.set('gallery', gallery);
    res.json({ success: true, message: 'Photo deleted.' });
  } catch (err) {
    console.error('[Gallery/DELETE]', err);
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

module.exports = router;
