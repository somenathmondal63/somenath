/**
 * routes/medicines.js
 * CRUD for medicine inventory.
 * Public: GET (search + filter)
 * Admin: POST, PUT, DELETE
 */

const express = require('express');
const router  = express.Router();
const { v4: uuidv4 } = require('uuid');
const db      = require('../db');
const { requireAuth } = require('../middleware/auth');

const VALID_STATUSES   = ['available', 'limited', 'out'];
const VALID_CATEGORIES = ['Pain Relief','Antibiotic','Diabetes','Blood Pressure','Allergy','Antacid','Vitamins','Other'];

// ─── GET /api/medicines ───────────────────────────────────────────────────────
// Public: list all medicines with optional search & category filter
router.get('/', (req, res) => {
  try {
    let medicines = db.get('medicines') || [];
    const { search, category, status } = req.query;

    if (search) {
      const q = search.toLowerCase();
      medicines = medicines.filter(m => m.name.toLowerCase().includes(q));
    }
    if (category) {
      medicines = medicines.filter(m => m.category === category);
    }
    if (status) {
      medicines = medicines.filter(m => m.status === status);
    }

    res.json({ success: true, total: medicines.length, data: medicines });
  } catch (err) {
    console.error('[Medicines/GET]', err);
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

// ─── POST /api/medicines ──────────────────────────────────────────────────────
// Admin: add a new medicine
router.post('/', requireAuth, (req, res) => {
  try {
    const { name, category, status } = req.body;

    if (!name || !name.trim()) {
      return res.status(400).json({ success: false, message: 'Medicine name is required.' });
    }
    if (category && !VALID_CATEGORIES.includes(category)) {
      return res.status(400).json({ success: false, message: 'Invalid category.' });
    }
    if (status && !VALID_STATUSES.includes(status)) {
      return res.status(400).json({ success: false, message: 'Invalid status. Use: available, limited, out.' });
    }

    const medicine = {
      id:       uuidv4(),
      name:     name.trim(),
      category: category || 'Other',
      status:   status   || 'available'
    };

    const medicines = db.get('medicines') || [];
    medicines.push(medicine);
    db.set('medicines', medicines);

    res.status(201).json({ success: true, message: 'Medicine added.', data: medicine });
  } catch (err) {
    console.error('[Medicines/POST]', err);
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

// ─── PUT /api/medicines/:id ───────────────────────────────────────────────────
// Admin: update a medicine
router.put('/:id', requireAuth, (req, res) => {
  try {
    const medicines = db.get('medicines') || [];
    const idx = medicines.findIndex(m => m.id === req.params.id);

    if (idx === -1) {
      return res.status(404).json({ success: false, message: 'Medicine not found.' });
    }

    const { name, category, status } = req.body;
    if (name)     medicines[idx].name     = name.trim();
    if (category) medicines[idx].category = category;
    if (status) {
      if (!VALID_STATUSES.includes(status)) {
        return res.status(400).json({ success: false, message: 'Invalid status.' });
      }
      medicines[idx].status = status;
    }

    db.set('medicines', medicines);
    res.json({ success: true, message: 'Medicine updated.', data: medicines[idx] });
  } catch (err) {
    console.error('[Medicines/PUT]', err);
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

// ─── DELETE /api/medicines/:id ────────────────────────────────────────────────
// Admin: remove a medicine
router.delete('/:id', requireAuth, (req, res) => {
  try {
    const medicines = db.get('medicines') || [];
    const idx = medicines.findIndex(m => m.id === req.params.id);

    if (idx === -1) {
      return res.status(404).json({ success: false, message: 'Medicine not found.' });
    }

    medicines.splice(idx, 1);
    db.set('medicines', medicines);
    res.json({ success: true, message: 'Medicine removed.' });
  } catch (err) {
    console.error('[Medicines/DELETE]', err);
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

// ─── PUT /api/medicines/bulk ──────────────────────────────────────────────────
// Admin: replace the entire medicines list at once
router.put('/bulk/replace', requireAuth, (req, res) => {
  try {
    const { medicines } = req.body;
    if (!Array.isArray(medicines)) {
      return res.status(400).json({ success: false, message: 'medicines must be an array.' });
    }
    const cleaned = medicines.map(m => ({
      id:       m.id || uuidv4(),
      name:     String(m.name || '').trim(),
      category: VALID_CATEGORIES.includes(m.category) ? m.category : 'Other',
      status:   VALID_STATUSES.includes(m.status)     ? m.status   : 'available'
    })).filter(m => m.name);

    db.set('medicines', cleaned);
    res.json({ success: true, message: `${cleaned.length} medicines saved.`, data: cleaned });
  } catch (err) {
    console.error('[Medicines/BulkReplace]', err);
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

module.exports = router;
