/**
 * routes/admins.js
 * Admin management — MAIN ADMIN ONLY.
 * Add / list / remove other admins.
 * The main admin can NEVER be removed.
 */

const express = require('express');
const router  = express.Router();
const bcrypt  = require('bcryptjs');
const { v4: uuidv4 } = require('uuid');
const db      = require('../db');
const { requireAuth, requireMainAdmin } = require('../middleware/auth');

// All routes here require auth + main admin
router.use(requireAuth, requireMainAdmin);

// ─── GET /api/admins ──────────────────────────────────────────────────────────
// Main admin: list all other admins (passwords are never returned)
router.get('/', (req, res) => {
  try {
    const admins = (db.get('admins') || []).map(a => ({
      id:     a.id,
      name:   a.name,
      mobile: a.mobile.replace(/(\d{3})\d{5}(\d{2})/, '$1•••••$2'),  // masked
      addedAt: a.addedAt
    }));
    res.json({ success: true, total: admins.length, data: admins });
  } catch (err) {
    console.error('[Admins/GET]', err);
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

// ─── POST /api/admins ─────────────────────────────────────────────────────────
// Main admin: add a new admin
router.post('/', async (req, res) => {
  try {
    const { name, mobile, password } = req.body;

    if (!name || !mobile || !password) {
      return res.status(400).json({ success: false, message: 'Name, mobile, and password are required.' });
    }
    if (password.length < 6) {
      return res.status(400).json({ success: false, message: 'Password must be at least 6 characters.' });
    }

    // Guard: cannot use main admin's mobile
    if (mobile === process.env.MAIN_ADMIN_MOBILE) {
      return res.status(400).json({ success: false, message: 'This mobile number is reserved.' });
    }

    const admins = db.get('admins') || [];
    if (admins.find(a => a.mobile === mobile)) {
      return res.status(409).json({ success: false, message: 'An admin with this mobile already exists.' });
    }

    const hashed = await bcrypt.hash(password, 10);
    const admin  = {
      id:       uuidv4(),
      name:     name.trim(),
      mobile:   mobile.trim(),
      password: hashed,
      addedAt:  new Date().toISOString()
    };

    admins.push(admin);
    db.set('admins', admins);

    res.status(201).json({
      success: true,
      message: 'Admin added successfully.',
      data: { id: admin.id, name: admin.name }
    });
  } catch (err) {
    console.error('[Admins/POST]', err);
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

// ─── DELETE /api/admins/:id ───────────────────────────────────────────────────
// Main admin: remove another admin (cannot remove main admin)
router.delete('/:id', (req, res) => {
  try {
    const admins = db.get('admins') || [];
    const idx = admins.findIndex(a => a.id === req.params.id);

    if (idx === -1) {
      return res.status(404).json({ success: false, message: 'Admin not found.' });
    }

    // Safety check: main admin's mobile should never appear in the admins array,
    // but double-guard just in case.
    if (admins[idx].mobile === process.env.MAIN_ADMIN_MOBILE) {
      return res.status(403).json({ success: false, message: 'The Main Admin cannot be removed.' });
    }

    const removed = admins.splice(idx, 1)[0];
    db.set('admins', admins);

    res.json({ success: true, message: `Admin "${removed.name}" removed.` });
  } catch (err) {
    console.error('[Admins/DELETE]', err);
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

// ─── PUT /api/admins/:id/reset-password ──────────────────────────────────────
// Main admin: reset another admin's password
router.put('/:id/reset-password', async (req, res) => {
  try {
    const { newPassword } = req.body;
    if (!newPassword || newPassword.length < 6) {
      return res.status(400).json({ success: false, message: 'Password must be at least 6 characters.' });
    }

    const admins = db.get('admins') || [];
    const idx    = admins.findIndex(a => a.id === req.params.id);
    if (idx === -1) return res.status(404).json({ success: false, message: 'Admin not found.' });

    admins[idx].password = await bcrypt.hash(newPassword, 10);
    db.set('admins', admins);

    res.json({ success: true, message: 'Password reset successfully.' });
  } catch (err) {
    console.error('[Admins/reset-password]', err);
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

module.exports = router;
