/**
 * routes/doctors.js
 * CRUD for visiting doctors.
 * Public: GET
 * Admin: POST, PUT, DELETE
 */

const express = require('express');
const router  = express.Router();
const { v4: uuidv4 } = require('uuid');
const db      = require('../db');
const { requireAuth } = require('../middleware/auth');

// ─── GET /api/doctors ─────────────────────────────────────────────────────────
router.get('/', (req, res) => {
  try {
    const doctors = db.get('doctors') || [];
    res.json({ success: true, total: doctors.length, data: doctors });
  } catch (err) {
    console.error('[Doctors/GET]', err);
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

// ─── GET /api/doctors/:id ─────────────────────────────────────────────────────
router.get('/:id', (req, res) => {
  try {
    const doctors = db.get('doctors') || [];
    const doctor = doctors.find(d => d.id === req.params.id);
    if (!doctor) return res.status(404).json({ success: false, message: 'Doctor not found.' });
    res.json({ success: true, data: doctor });
  } catch (err) {
    console.error('[Doctors/GET/:id]', err);
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

// ─── POST /api/doctors ────────────────────────────────────────────────────────
router.post('/', requireAuth, (req, res) => {
  try {
    const { name, spec, schedule, exp, lang, emoji } = req.body;

    if (!name || !name.trim()) {
      return res.status(400).json({ success: false, message: 'Doctor name is required.' });
    }

    const doctor = {
      id:       uuidv4(),
      name:     (name     || '').trim(),
      spec:     (spec     || '').trim(),
      schedule: (schedule || '').trim(),
      exp:      (exp      || '').trim(),
      lang:     (lang     || '').trim(),
      emoji:    emoji || '👨‍⚕️'
    };

    const doctors = db.get('doctors') || [];
    doctors.push(doctor);
    db.set('doctors', doctors);

    res.status(201).json({ success: true, message: 'Doctor added.', data: doctor });
  } catch (err) {
    console.error('[Doctors/POST]', err);
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

// ─── PUT /api/doctors/:id ─────────────────────────────────────────────────────
router.put('/:id', requireAuth, (req, res) => {
  try {
    const doctors = db.get('doctors') || [];
    const idx = doctors.findIndex(d => d.id === req.params.id);

    if (idx === -1) return res.status(404).json({ success: false, message: 'Doctor not found.' });

    const fields = ['name', 'spec', 'schedule', 'exp', 'lang', 'emoji'];
    for (const f of fields) {
      if (req.body[f] !== undefined) {
        doctors[idx][f] = String(req.body[f]).trim();
      }
    }

    db.set('doctors', doctors);
    res.json({ success: true, message: 'Doctor updated.', data: doctors[idx] });
  } catch (err) {
    console.error('[Doctors/PUT]', err);
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

// ─── DELETE /api/doctors/:id ──────────────────────────────────────────────────
router.delete('/:id', requireAuth, (req, res) => {
  try {
    const doctors = db.get('doctors') || [];
    const idx = doctors.findIndex(d => d.id === req.params.id);

    if (idx === -1) return res.status(404).json({ success: false, message: 'Doctor not found.' });

    doctors.splice(idx, 1);
    db.set('doctors', doctors);
    res.json({ success: true, message: 'Doctor removed.' });
  } catch (err) {
    console.error('[Doctors/DELETE]', err);
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

// ─── PUT /api/doctors/bulk/replace ───────────────────────────────────────────
router.put('/bulk/replace', requireAuth, (req, res) => {
  try {
    const { doctors } = req.body;
    if (!Array.isArray(doctors)) {
      return res.status(400).json({ success: false, message: 'doctors must be an array.' });
    }
    const cleaned = doctors.map(d => ({
      id:       d.id || uuidv4(),
      name:     String(d.name     || '').trim(),
      spec:     String(d.spec     || '').trim(),
      schedule: String(d.schedule || '').trim(),
      exp:      String(d.exp      || '').trim(),
      lang:     String(d.lang     || '').trim(),
      emoji:    d.emoji || '👨‍⚕️'
    })).filter(d => d.name);

    db.set('doctors', cleaned);
    res.json({ success: true, message: `${cleaned.length} doctors saved.`, data: cleaned });
  } catch (err) {
    console.error('[Doctors/BulkReplace]', err);
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

module.exports = router;
