/**
 * routes/reviews.js
 * Customer reviews: submit (public), moderate (admin).
 * Supports photo/video upload via multipart/form-data.
 */

const express = require('express');
const router  = express.Router();
const multer  = require('multer');
const path    = require('path');
const fs      = require('fs');
const { v4: uuidv4 } = require('uuid');
const db      = require('../db');
const { requireAuth } = require('../middleware/auth');

// ─── Multer storage for review media ─────────────────────────────────────────
const UPLOAD_DIR = path.join(__dirname, '..', 'uploads', 'reviews');
if (!fs.existsSync(UPLOAD_DIR)) fs.mkdirSync(UPLOAD_DIR, { recursive: true });

const storage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, UPLOAD_DIR),
  filename:    (_req, file, cb) => {
    const ext  = path.extname(file.originalname).toLowerCase();
    const name = `${uuidv4()}${ext}`;
    cb(null, name);
  }
});

const fileFilter = (_req, file, cb) => {
  const allowed = /jpeg|jpg|png|gif|webp|mp4|mov|avi|mkv/;
  const ext = allowed.test(path.extname(file.originalname).toLowerCase());
  const mime = allowed.test(file.mimetype);
  if (ext && mime) return cb(null, true);
  cb(new Error('Only image and video files are allowed.'));
};

const upload = multer({
  storage,
  fileFilter,
  limits: { fileSize: (parseInt(process.env.MAX_UPLOAD_MB) || 10) * 1024 * 1024 }
});

// ─── Month helper ─────────────────────────────────────────────────────────────
function formatDate() {
  const months = ['January','February','March','April','May','June',
                  'July','August','September','October','November','December'];
  const now = new Date();
  return `${months[now.getMonth()]} ${now.getFullYear()}`;
}

// ─── GET /api/reviews ─────────────────────────────────────────────────────────
// Public: returns only approved reviews
router.get('/', (req, res) => {
  try {
    const all = db.get('reviews') || [];
    const data = all
      .filter(r => r.approved)
      .map(({ id, name, rating, text, date, media }) => ({ id, name, rating, text, date, media }));
    res.json({ success: true, total: data.length, data });
  } catch (err) {
    console.error('[Reviews/GET]', err);
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

// ─── GET /api/reviews/all (admin) ────────────────────────────────────────────
router.get('/all', requireAuth, (req, res) => {
  try {
    const all = db.get('reviews') || [];
    res.json({ success: true, total: all.length, data: all });
  } catch (err) {
    console.error('[Reviews/all]', err);
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

// ─── POST /api/reviews ────────────────────────────────────────────────────────
// Public: submit a new review (pending approval)
router.post('/', upload.array('media', 5), (req, res) => {
  try {
    const { name, rating, text } = req.body;

    // Validation
    if (!name || !name.trim()) {
      return res.status(400).json({ success: false, message: 'Name is required.' });
    }
    const ratingNum = parseInt(rating);
    if (isNaN(ratingNum) || ratingNum < 1 || ratingNum > 5) {
      return res.status(400).json({ success: false, message: 'Rating must be between 1 and 5.' });
    }
    if (!text || !text.trim()) {
      return res.status(400).json({ success: false, message: 'Feedback text is required.' });
    }

    const mediaFiles = (req.files || []).map(f => ({
      filename: f.filename,
      mimetype: f.mimetype,
      url: `/uploads/reviews/${f.filename}`
    }));

    const review = {
      id:       uuidv4(),
      name:     name.trim(),
      rating:   ratingNum,
      text:     text.trim(),
      date:     formatDate(),
      approved: false,    // Admin must approve before it's public
      media:    mediaFiles,
      submittedAt: new Date().toISOString()
    };

    const reviews = db.get('reviews') || [];
    reviews.unshift(review);
    db.set('reviews', reviews);

    res.status(201).json({
      success: true,
      message: 'Thank you! Your review has been submitted and is pending approval.',
      data: { id: review.id }
    });
  } catch (err) {
    console.error('[Reviews/POST]', err);
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

// ─── PUT /api/reviews/:id/approve ────────────────────────────────────────────
// Admin: approve a review
router.put('/:id/approve', requireAuth, (req, res) => {
  try {
    const reviews = db.get('reviews') || [];
    const idx = reviews.findIndex(r => r.id === req.params.id);
    if (idx === -1) return res.status(404).json({ success: false, message: 'Review not found.' });

    reviews[idx].approved = true;
    db.set('reviews', reviews);
    res.json({ success: true, message: 'Review approved.' });
  } catch (err) {
    console.error('[Reviews/approve]', err);
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

// ─── PUT /api/reviews/:id/hide ────────────────────────────────────────────────
// Admin: hide/unapprove a review
router.put('/:id/hide', requireAuth, (req, res) => {
  try {
    const reviews = db.get('reviews') || [];
    const idx = reviews.findIndex(r => r.id === req.params.id);
    if (idx === -1) return res.status(404).json({ success: false, message: 'Review not found.' });

    reviews[idx].approved = false;
    db.set('reviews', reviews);
    res.json({ success: true, message: 'Review hidden.' });
  } catch (err) {
    console.error('[Reviews/hide]', err);
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

// ─── DELETE /api/reviews/:id ─────────────────────────────────────────────────
// Admin: delete a review and its media files
router.delete('/:id', requireAuth, (req, res) => {
  try {
    const reviews = db.get('reviews') || [];
    const idx = reviews.findIndex(r => r.id === req.params.id);
    if (idx === -1) return res.status(404).json({ success: false, message: 'Review not found.' });

    // Delete uploaded media files
    const review = reviews[idx];
    (review.media || []).forEach(m => {
      const filePath = path.join(UPLOAD_DIR, m.filename);
      if (fs.existsSync(filePath)) fs.unlinkSync(filePath);
    });

    reviews.splice(idx, 1);
    db.set('reviews', reviews);
    res.json({ success: true, message: 'Review deleted.' });
  } catch (err) {
    console.error('[Reviews/DELETE]', err);
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

module.exports = router;
