/**
 * routes/auth.js
 * Admin authentication: login & forgot-password (no OTP required per spec).
 */

const express  = require('express');
const bcrypt   = require('bcryptjs');
const router   = express.Router();
const db       = require('../db');
const { generateToken, requireAuth } = require('../middleware/auth');

// ─── Main admin credentials from .env ────────────────────────────────────────
const MAIN = {
  mobile:   process.env.MAIN_ADMIN_MOBILE,
  password: process.env.MAIN_ADMIN_PASSWORD,
  doc1:     process.env.MAIN_ADMIN_DOC1,
  doc2:     process.env.MAIN_ADMIN_DOC2,
  dob:      process.env.MAIN_ADMIN_DOB,
  name:     'Main Admin',
  isMain:   true
};

// ─── POST /api/auth/login ─────────────────────────────────────────────────────
/**
 * Login with mobile + password.
 * No OTP required (as per spec).
 * Returns JWT token.
 */
router.post('/login', async (req, res) => {
  try {
    const { mobile, password } = req.body;

    if (!mobile || !password) {
      return res.status(400).json({ success: false, message: 'Mobile and password are required.' });
    }

    // Check main admin (plain text comparison since it's env-stored)
    if (mobile === MAIN.mobile && password === MAIN.password) {
      const token = generateToken({ mobile: MAIN.mobile, isMain: true, name: MAIN.name });
      return res.json({
        success: true,
        token,
        admin: { name: MAIN.name, isMain: true }
      });
    }

    // Check other admins in database
    const admins = db.get('admins') || [];
    const found  = admins.find(a => a.mobile === mobile);

    if (!found) {
      return res.status(401).json({ success: false, message: 'Invalid mobile number or password.' });
    }

    // Password can be plain or bcrypt hashed
    let passwordMatch = false;
    if (found.password.startsWith('$2')) {
      passwordMatch = await bcrypt.compare(password, found.password);
    } else {
      passwordMatch = found.password === password;
    }

    if (!passwordMatch) {
      return res.status(401).json({ success: false, message: 'Invalid mobile number or password.' });
    }

    const token = generateToken({ mobile: found.mobile, isMain: false, name: found.name });
    return res.json({
      success: true,
      token,
      admin: { name: found.name, isMain: false }
    });

  } catch (err) {
    console.error('[Auth/Login]', err);
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

// ─── POST /api/auth/forgot-password ──────────────────────────────────────────
/**
 * Verify identity using: doc1 + doc2 + dob + mobile.
 * If verified, allow setting a new password.
 * No OTP required.
 */
router.post('/forgot-password', async (req, res) => {
  try {
    const { mobile, doc1, doc2, dob, newPassword } = req.body;

    if (!mobile || !doc1 || !doc2 || !dob) {
      return res.status(400).json({ success: false, message: 'All verification fields are required.' });
    }

    // Verify main admin
    const isMainAdmin =
      mobile === MAIN.mobile &&
      doc1   === MAIN.doc1   &&
      doc2   === MAIN.doc2   &&
      dob    === MAIN.dob;

    // Verify other admin (uses main admin doc credentials + own mobile)
    const admins    = db.get('admins') || [];
    const otherAdmin = admins.find(a => a.mobile === mobile);
    const isOtherAdmin =
      otherAdmin     &&
      doc1 === MAIN.doc1 &&
      doc2 === MAIN.doc2 &&
      dob  === MAIN.dob;

    if (!isMainAdmin && !isOtherAdmin) {
      return res.status(401).json({ success: false, message: 'Verification failed. Please check your details.' });
    }

    // If newPassword not provided, just confirm verification
    if (!newPassword) {
      return res.json({ success: true, verified: true, message: 'Identity verified. You may now set a new password.' });
    }

    if (newPassword.length < 6) {
      return res.status(400).json({ success: false, message: 'Password must be at least 6 characters.' });
    }

    if (isMainAdmin) {
      // Main admin password is stored in .env — cannot be changed via API in this implementation.
      // In production: update the env variable and restart, or store in a secure vault.
      return res.json({
        success: true,
        message: 'Main Admin password reset is managed via server environment. Please update .env and restart.'
      });
    }

    // Update other admin password
    const hashed = await bcrypt.hash(newPassword, 10);
    const idx    = admins.findIndex(a => a.mobile === mobile);
    admins[idx].password = hashed;
    db.set('admins', admins);

    return res.json({ success: true, message: 'Password reset successfully. You may now login.' });

  } catch (err) {
    console.error('[Auth/ForgotPassword]', err);
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

// ─── GET /api/auth/me ─────────────────────────────────────────────────────────
/**
 * Return current admin info from token.
 */
router.get('/me', requireAuth, (req, res) => {
  res.json({ success: true, admin: req.admin });
});

module.exports = router;
