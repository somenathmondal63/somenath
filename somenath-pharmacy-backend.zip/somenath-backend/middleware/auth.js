/**
 * middleware/auth.js
 * JWT authentication middleware for protected admin routes.
 */

const jwt = require('jsonwebtoken');

const JWT_SECRET = process.env.JWT_SECRET || 'fallback_secret_change_in_production';

/**
 * Verify JWT token from Authorization header.
 * Attaches decoded payload to req.admin.
 */
function requireAuth(req, res, next) {
  const header = req.headers['authorization'];
  if (!header || !header.startsWith('Bearer ')) {
    return res.status(401).json({ success: false, message: 'No token provided. Please login.' });
  }

  const token = header.slice(7);
  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    req.admin = decoded; // { mobile, isMain, name }
    next();
  } catch (err) {
    return res.status(401).json({ success: false, message: 'Invalid or expired token. Please login again.' });
  }
}

/**
 * Require the logged-in admin to be the Main Admin.
 */
function requireMainAdmin(req, res, next) {
  if (!req.admin || !req.admin.isMain) {
    return res.status(403).json({ success: false, message: 'This action requires Main Admin privileges.' });
  }
  next();
}

/**
 * Generate a JWT token for an admin.
 */
function generateToken(payload) {
  return jwt.sign(payload, JWT_SECRET, {
    expiresIn: process.env.JWT_EXPIRES_IN || '7d'
  });
}

module.exports = { requireAuth, requireMainAdmin, generateToken };
