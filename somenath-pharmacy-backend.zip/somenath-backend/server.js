/**
 * ╔══════════════════════════════════════════════════════════╗
 * ║         SOMENATH PHARMACY — BACKEND SERVER               ║
 * ║         Node.js + Express REST API                       ║
 * ║         Owner: Somenath Mondal                           ║
 * ╚══════════════════════════════════════════════════════════╝
 *
 * Start: node server.js  (or: npm start)
 * Dev:   npm run dev      (hot-reload with nodemon)
 *
 * API Base: http://localhost:3000/api
 */

require('dotenv').config();

const express     = require('express');
const cors        = require('cors');
const helmet      = require('helmet');
const morgan      = require('morgan');
const path        = require('path');
const rateLimit   = require('express-rate-limit');

// ─── Route modules ────────────────────────────────────────────────────────────
const authRoutes      = require('./routes/auth');
const businessRoutes  = require('./routes/business');
const medicinesRoutes = require('./routes/medicines');
const doctorsRoutes   = require('./routes/doctors');
const reviewsRoutes   = require('./routes/reviews');
const adminsRoutes    = require('./routes/admins');
const galleryRoutes   = require('./routes/gallery');

// ─── App init ─────────────────────────────────────────────────────────────────
const app  = express();
const PORT = process.env.PORT || 3000;

// ─── Security middleware ──────────────────────────────────────────────────────
app.use(helmet({
  crossOriginResourcePolicy: { policy: 'cross-origin' }  // allow serving uploaded images
}));

// CORS — allow frontend origin
const ALLOWED_ORIGINS = [
  process.env.FRONTEND_ORIGIN || 'http://localhost:5173',
  'http://localhost:3001',
  'http://127.0.0.1:5500'  // Live Server (dev)
];
app.use(cors({
  origin: (origin, cb) => {
    // Allow requests with no origin (Postman, curl, mobile apps)
    if (!origin) return cb(null, true);
    if (ALLOWED_ORIGINS.includes(origin)) return cb(null, true);
    cb(new Error(`CORS: Origin ${origin} not allowed.`));
  },
  credentials: true
}));

// ─── General middleware ───────────────────────────────────────────────────────
app.use(morgan(process.env.NODE_ENV === 'production' ? 'combined' : 'dev'));
app.use(express.json({ limit: '2mb' }));
app.use(express.urlencoded({ extended: true, limit: '2mb' }));

// ─── Static files — uploaded images/videos ────────────────────────────────────
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// ─── Rate limiting ────────────────────────────────────────────────────────────
const apiLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,   // 15 minutes
  max: 200,
  standardHeaders: true,
  legacyHeaders: false,
  message: { success: false, message: 'Too many requests. Please try again later.' }
});

const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 10,                    // max 10 login attempts per 15 min
  message: { success: false, message: 'Too many login attempts. Please try again after 15 minutes.' }
});

app.use('/api/', apiLimiter);
app.use('/api/auth/login', loginLimiter);

// ─── API Routes ───────────────────────────────────────────────────────────────
app.use('/api/auth',      authRoutes);
app.use('/api/business',  businessRoutes);
app.use('/api/medicines', medicinesRoutes);
app.use('/api/doctors',   doctorsRoutes);
app.use('/api/reviews',   reviewsRoutes);
app.use('/api/admins',    adminsRoutes);
app.use('/api/gallery',   galleryRoutes);

// ─── Health check ─────────────────────────────────────────────────────────────
app.get('/api/health', (_req, res) => {
  res.json({
    success: true,
    service: 'Somenath Pharmacy API',
    status:  'running',
    time:    new Date().toISOString()
  });
});

// ─── Root info ────────────────────────────────────────────────────────────────
app.get('/', (_req, res) => {
  res.json({
    service:  'Somenath Pharmacy Backend API',
    version:  '1.0.0',
    owner:    'Somenath Mondal',
    website:  'somenath.pharmacy.com',
    endpoints: {
      health:    'GET  /api/health',
      auth:      'POST /api/auth/login | POST /api/auth/forgot-password | GET /api/auth/me',
      business:  'GET  /api/business  | PUT /api/business  (admin)',
      medicines: 'GET  /api/medicines | POST/PUT/DELETE /api/medicines (admin)',
      doctors:   'GET  /api/doctors   | POST/PUT/DELETE /api/doctors   (admin)',
      reviews:   'GET  /api/reviews   | POST /api/reviews (public) | PUT/DELETE (admin)',
      gallery:   'GET  /api/gallery   | POST/DELETE /api/gallery (admin)',
      admins:    'GET/POST/DELETE /api/admins  (main admin only)'
    }
  });
});

// ─── 404 handler ─────────────────────────────────────────────────────────────
app.use((_req, res) => {
  res.status(404).json({ success: false, message: 'Route not found.' });
});

// ─── Global error handler ─────────────────────────────────────────────────────
app.use((err, _req, res, _next) => {
  console.error('[Server Error]', err.message);
  if (err.code === 'LIMIT_FILE_SIZE') {
    return res.status(413).json({ success: false, message: `File too large. Max size: ${process.env.MAX_UPLOAD_MB || 10}MB.` });
  }
  res.status(500).json({ success: false, message: err.message || 'Internal server error.' });
});

// ─── Start server ─────────────────────────────────────────────────────────────
app.listen(PORT, () => {
  console.log('\n╔══════════════════════════════════════════════════╗');
  console.log('║       SOMENATH PHARMACY — API Server             ║');
  console.log('╠══════════════════════════════════════════════════╣');
  console.log(`║  Running at : http://localhost:${PORT}              ║`);
  console.log(`║  Environment: ${(process.env.NODE_ENV || 'development').padEnd(34)}║`);
  console.log('║  Endpoints  : GET /  for full route list         ║');
  console.log('╚══════════════════════════════════════════════════╝\n');
});

module.exports = app;
