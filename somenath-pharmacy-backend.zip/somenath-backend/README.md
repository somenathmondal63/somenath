# 💊 Somenath Pharmacy — Backend API

**Node.js + Express REST API** for the Somenath Pharmacy website.

---

## 🚀 Quick Start

```bash
# 1. Install dependencies
npm install

# 2. Set up environment
cp .env.example .env
# Edit .env with your values

# 3. Start server
npm start          # production
npm run dev        # development (auto-reload)
```

Server runs at: `http://localhost:3000`

---

## 📁 Project Structure

```
somenath-backend/
├── server.js              ← Main entry point
├── db.js                  ← JSON file-based database
├── package.json
├── .env.example           ← Copy to .env
├── data/
│   └── database.json      ← Auto-created on first run
├── uploads/
│   ├── gallery/           ← Shop photos
│   └── reviews/           ← Customer review media
├── middleware/
│   └── auth.js            ← JWT auth middleware
└── routes/
    ├── auth.js            ← Login, forgot password
    ├── business.js        ← Business info (address, hours, phone)
    ├── medicines.js       ← Medicine inventory CRUD
    ├── doctors.js         ← Visiting doctors CRUD
    ├── reviews.js         ← Customer reviews + file upload
    ├── gallery.js         ← Shop gallery photos
    └── admins.js          ← Admin management (main admin only)
```

---

## 🔐 Authentication

All **admin** routes require a `Bearer` JWT token in the header:

```
Authorization: Bearer <your_jwt_token>
```

### Login

```
POST /api/auth/login
Content-Type: application/json

{ "mobile": "6294125663", "password": "YourPassword" }
```

**Response:**
```json
{
  "success": true,
  "token": "eyJhbGci...",
  "admin": { "name": "Main Admin", "isMain": true }
}
```

### Forgot Password

```
POST /api/auth/forgot-password
Content-Type: application/json

{
  "mobile": "6294125663",
  "doc1": "WB35252465198",
  "doc2": "WB35252465061",
  "dob": "03-01-1959",
  "newPassword": "newpassword123"
}
```

### Current Admin Info

```
GET /api/auth/me
Authorization: Bearer <token>
```

---

## 📋 Business Info

### Get business info (Public)
```
GET /api/business
```

### Update business info (Admin)
```
PUT /api/business
Authorization: Bearer <token>
Content-Type: application/json

{
  "address": "123 Main Street, Kolkata, WB 700001",
  "phone": "9876543210",
  "whatsapp": "9876543210",
  "email": "somenath@pharmacy.com",
  "monsat": "7:00 AM – 9:00 PM",
  "sunday": "8:00 AM – 2:00 PM",
  "maps_embed": "https://maps.google.com/embed?...",
  "maps_address": "Somenath Pharmacy, Kolkata"
}
```

---

## 💊 Medicines

### Get all medicines (Public, with search/filter)
```
GET /api/medicines
GET /api/medicines?search=paracetamol
GET /api/medicines?category=Antibiotic
GET /api/medicines?status=available
```

### Add medicine (Admin)
```
POST /api/medicines
Authorization: Bearer <token>
Content-Type: application/json

{
  "name": "Paracetamol 500mg",
  "category": "Pain Relief",
  "status": "available"
}
```
**Valid categories:** `Pain Relief`, `Antibiotic`, `Diabetes`, `Blood Pressure`, `Allergy`, `Antacid`, `Vitamins`, `Other`  
**Valid statuses:** `available`, `limited`, `out`

### Update medicine (Admin)
```
PUT /api/medicines/:id
Authorization: Bearer <token>
Content-Type: application/json

{ "status": "limited" }
```

### Delete medicine (Admin)
```
DELETE /api/medicines/:id
Authorization: Bearer <token>
```

### Bulk replace all medicines (Admin)
```
PUT /api/medicines/bulk/replace
Authorization: Bearer <token>
Content-Type: application/json

{ "medicines": [ { "name": "...", "category": "...", "status": "..." } ] }
```

---

## 🩺 Doctors

### Get all doctors (Public)
```
GET /api/doctors
GET /api/doctors/:id
```

### Add doctor (Admin)
```
POST /api/doctors
Authorization: Bearer <token>
Content-Type: application/json

{
  "name": "Dr. Amit Sharma",
  "spec": "General Physician · MBBS, MD",
  "schedule": "Monday, Wednesday, Friday · 5:00 PM – 8:00 PM",
  "exp": "10+ years experience in general medicine.",
  "lang": "Bengali, Hindi, English",
  "emoji": "👨‍⚕️"
}
```

### Update doctor (Admin)
```
PUT /api/doctors/:id
Authorization: Bearer <token>
Content-Type: application/json

{ "schedule": "Tuesday, Thursday · 4:00 PM – 7:00 PM" }
```

### Delete doctor (Admin)
```
DELETE /api/doctors/:id
Authorization: Bearer <token>
```

---

## ⭐ Reviews

### Get approved reviews (Public)
```
GET /api/reviews
```

### Get all reviews including pending (Admin)
```
GET /api/reviews/all
Authorization: Bearer <token>
```

### Submit a review (Public) — multipart/form-data
```
POST /api/reviews
Content-Type: multipart/form-data

name=Rahul Das
rating=5
text=Excellent service!
media=<file>  (optional, up to 5 image/video files)
```

### Approve a review (Admin)
```
PUT /api/reviews/:id/approve
Authorization: Bearer <token>
```

### Hide a review (Admin)
```
PUT /api/reviews/:id/hide
Authorization: Bearer <token>
```

### Delete a review (Admin)
```
DELETE /api/reviews/:id
Authorization: Bearer <token>
```

---

## 📸 Gallery

### Get gallery photos (Public)
```
GET /api/gallery
```

### Upload photos (Admin) — multipart/form-data
```
POST /api/gallery
Authorization: Bearer <token>
Content-Type: multipart/form-data

photos=<file1>
photos=<file2>
label=Shop Front  (optional)
```

### Update photo label (Admin)
```
PUT /api/gallery/:id
Authorization: Bearer <token>
Content-Type: application/json

{ "label": "X-Ray Room" }
```

### Delete photo (Admin)
```
DELETE /api/gallery/:id
Authorization: Bearer <token>
```

---

## 👤 Admin Management (Main Admin Only)

### List all admins
```
GET /api/admins
Authorization: Bearer <main-admin-token>
```

### Add admin
```
POST /api/admins
Authorization: Bearer <main-admin-token>
Content-Type: application/json

{
  "name": "Ravi Kumar",
  "mobile": "9876543210",
  "password": "securepassword"
}
```

### Remove admin
```
DELETE /api/admins/:id
Authorization: Bearer <main-admin-token>
```

### Reset admin password
```
PUT /api/admins/:id/reset-password
Authorization: Bearer <main-admin-token>
Content-Type: application/json

{ "newPassword": "newpassword123" }
```

---

## 🏥 Health Check
```
GET /api/health
```

---

## 🌐 Deployment (Recommended)

### Option 1 — Render.com (Free)
1. Push code to GitHub
2. Create new Web Service on render.com
3. Set environment variables from `.env.example`
4. Deploy

### Option 2 — Railway.app
1. Connect GitHub repo
2. Add env vars in dashboard
3. Deploy automatically

### Option 3 — VPS (Ubuntu)
```bash
# Install Node.js
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs

# Clone & run
git clone <your-repo>
cd somenath-backend
npm install
cp .env.example .env && nano .env

# Use PM2 for process management
npm install -g pm2
pm2 start server.js --name somenath-pharmacy
pm2 startup
pm2 save
```

---

## ⚙️ Environment Variables

| Variable | Description | Example |
|---|---|---|
| `PORT` | Server port | `3000` |
| `NODE_ENV` | Environment | `production` |
| `JWT_SECRET` | Secret for JWT signing | `random_long_string` |
| `JWT_EXPIRES_IN` | Token expiry | `7d` |
| `MAIN_ADMIN_MOBILE` | Main admin mobile | `6294125663` |
| `MAIN_ADMIN_PASSWORD` | Main admin password | `Ajit8967&&&` |
| `MAIN_ADMIN_DOC1` | Verification document 1 | `WB35252465198` |
| `MAIN_ADMIN_DOC2` | Verification document 2 | `WB35252465061` |
| `MAIN_ADMIN_DOB` | Date of birth (DD-MM-YYYY) | `03-01-1959` |
| `MAX_UPLOAD_MB` | Max file upload size | `10` |
| `FRONTEND_ORIGIN` | Frontend URL for CORS | `https://somenath.pharmacy.com` |

---

*© 2025 Somenath Pharmacy. All rights reserved.*
